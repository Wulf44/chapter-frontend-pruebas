import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Personaje } from '../models/personajes';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PersonajesService {

  constructor(private http:HttpClient) { }

  getPersonajes():Observable<Personaje []>{ 
    return this.http.get<Personaje []>('https://bp-marvel-api.herokuapp.com/marvel-characters?idAuthor=53');
  }

  getPersonajesTitulo():Observable<Personaje []>{ 
    return this.http.get<Personaje []>('https://bp-marvel-api.herokuapp.com/marvel-characters?idAuthor=53&title=spider');
  }

  deletePersonaje(id:(string | undefined) ):Observable<any>{
      return this.http.delete(`http://bp-marvel-api.herokuapp.com/:id?idAuthor=${id}`);
    }

  postPersonaje(personaje:Personaje):Observable<Personaje> {
      return this.http.post<Personaje>('https://bp-marvel-api.herokuapp.com/marvel-characters?idAuthor=53',personaje);
    }

  }

