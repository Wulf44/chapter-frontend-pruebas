import { Component, OnInit } from '@angular/core';
import { PersonajesService } from '../services/personajes.service'
import { FormBuilder, FormGroup } from '@angular/forms';
import { Personaje } from '../models/personajes';

@Component({
  selector: 'app-personajes',
  templateUrl: './personajes.component.html',
  styleUrls: ['./personajes.component.css']
})
export class PersonajesComponent implements OnInit {


  personajes:Personaje[] = [];
  personaje: Personaje = {
    _id: '',
    title: '',
    body: '',
    image: '',
    category: '',
    idAuthor: '',
    createdAt: '',
    updatedAt: '',
  }

  personajeForm:FormGroup = new FormGroup({});
  formBuilder:FormBuilder = new FormBuilder();

  constructor(private personajesService:PersonajesService) { }

  ngOnInit(): void {

    this.personajesService.getPersonajes().subscribe((personajes:Personaje [])=>{
      this.personajes = personajes;
  });

  this.personajeForm = this.formBuilder.group({
    image: [''],
    title: [''],
    email: [''],
    gender: [''],
    company: [''],
    phone: [''],
    address:[''],
    balance:[''],
    isActive:[false]
    });

}
addPersonaje(){
  console.log(this.personajeForm.getRawValue());
  this.personaje = this.personajeForm.getRawValue();
  this.personajesService.postPersonaje(this.personaje).subscribe((newPersonaje:Personaje) => this.personajes.push(newPersonaje));
}
}